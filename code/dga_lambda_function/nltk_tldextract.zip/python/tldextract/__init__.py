"""Export tldextract's public interface."""

from .cli import __version__
from .tldextract import extract, TLDExtract
